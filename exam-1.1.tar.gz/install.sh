#!/bin/bash

yum install git && git clone https://github.com/tanlin50140137/exam.git && cd exam && chmod 0777 system && chmod 0777 system/.dvsd.php && chmod 0777 system/config && chmod 0777 .settings/.org.nums && chmod 0777 .settings/.org.shu && chmod 0777 subject/version.txt ;

exlDir = "./.external/";

if [ -d "$exlDir" ]; then 
	chmod 0777 "./.external" 
else
	mkdir "./.external" && chmod 0777 "./.external"
fi 

mv -vr ./exam ../exam && cd .. ;

echo "Exam Install OK";

