#!/bin/bash

yum install git && git clone https://github.com/tanlin50140137/exam.git && cp -rf ./exam ../ && rm -rf ./exam && chmod 0777 ../exam/system && chmod 0777 ../exam/system/.dvsd.php && chmod 0777 ../exam/system/config && chmod 0777 ../exam/.settings/.org.nums && chmod 0777 ../exam/.settings/.org.shu && chmod 0777 ../exam/subject/version.txt ;

if [ -d "../exam/.external/" ]; then 
	chmod 0777 "../exam/.external" ; 
else
	mkdir "../exam/.external" && chmod 0777 "../exam/.external" ;
fi

echo "Exam Install OK";
echo "###############################################";
echo "#                                             #";
echo "# Visit: http://IP/exam || http://www.xxx.com #";
echo "#                                             #";
echo "###############################################";

